-- =============================================================
-- Query 1: List all assignments for a selected course, ordered
-- by the soonest due date. Used by index.php course filter.
-- =============================================================
SELECT A.name, A.due_date, A.completion_status, C.course_name
FROM Assignment A
JOIN Course C ON A.course_id = C.course_id
WHERE C.course_name = ?
ORDER BY A.due_date ASC;

-- =============================================================
-- Query 2: Count completed vs incomplete assignments per course.
-- Used by UI "Summary Report" button.
-- =============================================================
SELECT 
    C.course_name,
    SUM(A.completion_status = 1) AS completed_count,
    SUM(A.completion_status = 0) AS incomplete_count
FROM Assignment A
JOIN Course C ON A.course_id = C.course_id
GROUP BY C.course_id
ORDER BY completed_count DESC;

-- =============================================================
-- Query 3: Show all assignments that are overdue.
-- Used by UI "Show Overdue" button.
-- =============================================================
SELECT A.name, C.course_name, A.due_date
FROM Assignment A
JOIN Course C ON A.course_id = C.course_id
WHERE A.due_date < CURDATE()
ORDER BY A.due_date;

-- =============================================================
-- Query 4: Show students and the number of courses they take.
-- Used by UI "Students: Course Count" button.
-- =============================================================
SELECT U.name, U.email, COUNT(T.course_id) AS num_courses
FROM User U
LEFT JOIN Takes T ON U.email = T.email
GROUP BY U.email
ORDER BY num_courses DESC;

-- =============================================================
-- Query 5: Show assignments grouped by type (homework, exam, etc)
-- and count how many of each type exist.
-- Used by UI "Assignment Types Summary" button.
-- =============================================================
SELECT type, COUNT(*) AS total
FROM Assignment
GROUP BY type
ORDER BY total DESC;

