<?php
$conn = new mysqli("localhost", "phpuser", "StrongPass123", "smart_assignment_planner");

$id     = $_POST['assignment_id'];
$name   = $_POST['name'];
$date   = $_POST['due_date'];
$status = $_POST['completion_status'];

$stmt = $conn->prepare("
UPDATE Assignment SET name=?, due_date=?, completion_status=? 
WHERE assignment_id=?");
$stmt->bind_param("ssii", $name, $date, $status, $id);
$stmt->execute();

header("Location: ../index.php?msg=Assignment+Updated");
exit;

