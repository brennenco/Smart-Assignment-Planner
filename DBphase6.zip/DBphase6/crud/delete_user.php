<?php
$conn = new mysqli("localhost", "phpuser", "StrongPass123", "smart_assignment_planner");

$email = $_POST['email'];

$stmt = $conn->prepare("DELETE FROM `User` WHERE email=?");
$stmt->bind_param("s", $email);
$stmt->execute();

header("Location: ../index.php?msg=User+Deleted");
exit;

