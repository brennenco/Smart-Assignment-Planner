<?php
$conn = new mysqli("localhost", "phpuser", "StrongPass123", "smart_assignment_planner");

$email = $_POST['email'];
$name  = $_POST['name'];

$stmt = $conn->prepare("UPDATE `User` SET name=? WHERE email=?");
$stmt->bind_param("ss", $name, $email);
$stmt->execute();

header("Location: ../index.php?msg=User+Updated");
exit;

