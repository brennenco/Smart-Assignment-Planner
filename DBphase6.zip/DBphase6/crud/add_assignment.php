<?php
$conn = new mysqli("localhost", "phpuser", "StrongPass123", "smart_assignment_planner");

$course_id  = $_POST['course_id'];
$name       = $_POST['name'];
$due_date   = $_POST['due_date'];
$type       = $_POST['type'];
$status     = isset($_POST['completion_status']) ? 1 : 0;

$stmt = $conn->prepare("
INSERT INTO Assignment (course_id, name, due_date, completion_status, type)
VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("issis", $course_id, $name, $due_date, $status, $type);
$stmt->execute();

header("Location: ../index.php?msg=Assignment+Added");
exit;

