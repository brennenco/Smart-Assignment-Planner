<?php
$conn = new mysqli("localhost", "phpuser", "StrongPass123", "smart_assignment_planner");

$email = $_POST['email'];
$name  = $_POST['name'];

$stmt = $conn->prepare("INSERT INTO `User` (email, name) VALUES (?, ?)");
$stmt->bind_param("ss", $email, $name);
$stmt->execute();

header("Location: ../index.php?msg=User+Added");
exit;

