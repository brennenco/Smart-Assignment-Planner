all CRUD scripts made using AI tools 

need to implement UI buttons for CRUD